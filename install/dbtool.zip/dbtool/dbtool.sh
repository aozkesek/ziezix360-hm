java --class-path lib/hsqldb-2.4.1.jar:lib/dbtool.jar org.ziezix360.hm.HMApp

